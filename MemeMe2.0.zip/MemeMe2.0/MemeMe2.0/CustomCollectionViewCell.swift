//
//  CustomCollectionViewCell.swift
//  MemeMe2.0
//
//  Created by Raghad Mah on 08/12/2018.
//  Copyright © 2018 Udacity. All rights reserved.
//

import UIKit

class CustomCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var memeImageView: UIImageView!
    
}
